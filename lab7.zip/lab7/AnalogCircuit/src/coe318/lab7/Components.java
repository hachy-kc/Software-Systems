/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package coe318.lab7;

/**
 *
 * @author hachi ndu
 */
public abstract class Components {
    protected double value;
    protected int a, b;
    
     /**
     * @return the value of the first node as an integer.
     */
    public int getNode1(){
        return this.a;
    }
}